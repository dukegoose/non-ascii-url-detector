# non-ascii-url-detector

Firefox web extension to detect non-ascii characters in URL's to prevent phishing attempts.

